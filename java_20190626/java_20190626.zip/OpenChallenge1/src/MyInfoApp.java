
public class MyInfoApp {

	public static void main(String[] args) {
		int n = 27;
		System.out.println("제 나이는 "+n+"세 입니다.");
		System.out.println("이름은 박승재 입니다.");
		System.out.println("잘 부탁 드립니다.");
	}

}
