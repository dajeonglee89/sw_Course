package com.exam;


public class Ex4 {
	public static void main(String[] args) {
		int h = 175;
		
		System.out.println(h / 100 + "m " + h % 100 + "cm");
	
		float pi = 3.141592f;
		System.out.println(Math.round(pi*1000) / 1000f);
	}

}
