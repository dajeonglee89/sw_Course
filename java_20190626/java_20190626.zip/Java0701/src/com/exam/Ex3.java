//대입연산자 (연산 후 저장하라)




package com.exam;

public class Ex3 {
	public static void main(String[] args) {
	int a = 0;
	a += 1;
	System.out.println(a);
	a *= 1;
	System.out.println(a);
	a -= 1;
	System.out.println(a);
	}
}
